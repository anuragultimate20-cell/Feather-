# FeatherClient — Fabric 1.21.1

A highly optimised, Feather-inspired Fabric client mod for Minecraft 1.21.1.  
Built for low-end devices and PojavLauncher while being fully compatible with  
the **Spunky Boost** modpack.

---

## Features

| Category      | Feature                            |
|---------------|------------------------------------|
| HUD           | FPS counter, CPS, Ping, Keystrokes, Armor HUD, Coordinates |
| Movement      | Toggle Sprint, Toggle Sneak, Zoom (smooth), Freelook |
| Render        | Custom Crosshair, Waypoints, Motion Blur (opt-in) |
| Performance   | FPS Booster Mode, Low-End Mode, Auto-detection, PojavLauncher mode |
| GUI           | ClickGUI (Right-Shift), HUD Editor (Right-Alt) |
| Cosmetics     | Cape system, Emotes (async-loaded) |
| Misc          | Screenshot Manager (dated folders) |

---

## Keybinds

| Key         | Action                   |
|-------------|--------------------------|
| Right-Shift | Open ClickGUI            |
| Right-Alt   | Open HUD Editor          |
| C (hold)    | Zoom                     |
| V (hold)    | Freelook                 |

---

## Building

### Requirements
- JDK 21+
- Internet access (first build downloads Minecraft assets)

```bash
# Clone / unzip the project, then:
./gradlew build
```

The compiled jar appears at:
```
build/libs/featherclient-1.0.0.jar
```

---

## Installation

1. Install **Fabric Loader 0.16.9** for Minecraft 1.21.1 via the [Fabric installer](https://fabricmc.net/use/).
2. Place `featherclient-1.0.0.jar` into your `.minecraft/mods/` folder.
3. Install **Fabric API** (required dependency).
4. Launch the game — FeatherClient auto-detects your device tier and applies sensible defaults.

---

## Spunky Boost Compatibility

FeatherClient is passive — it does not replace or conflict with:

- **Sodium** (rendering)   — FeatherClient uses `DrawContext` / batched rendering only
- **Lithium** (logic)      — no game-loop overrides that conflict with Lithium
- **ImmediatelyFast**      — FeatherClient rendering goes through the same pipeline
- **EntityCulling / MoreCulling** — no entity-visibility overrides
- **Iris** (shaders)       — Motion Blur is disabled by default; no shader conflicts
- **Noisium**              — no chunk-gen overrides
- **FerriteCore**          — no memory model changes

> **Tip:** Keep Motion Blur **off** when using Iris shaders — they already handle post-processing.

---

## PojavLauncher / Android Mode

PojavLauncher is detected automatically via the `pojav_launcher` system property.  
When detected, Low-End Mode activates immediately with these settings:

- View distance: 6 chunks
- Simulation distance: 5 chunks
- Entity distance: 50 %
- Mipmap: 1 level
- Particles: Minimal
- Clouds: Off
- Fancy graphics: Off

You can fine-tune further in the ClickGUI → Performance tab.

---

## Config

Config file: `.minecraft/config/featherclient.json`  
Auto-created on first launch with safe defaults.  
Editable manually (JSON) or via the ClickGUI.

---

## License

MIT — free to use, modify, and redistribute.
