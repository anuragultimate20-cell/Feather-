package com.featherclient.config;

import com.google.gson.annotations.SerializedName;

/**
 * Plain data object holding every user-configurable option.
 * Serialized to / deserialized from JSON by ConfigManager.
 *
 * All fields have safe defaults so a first-run (no config file)
 * produces a stable, optimized experience automatically.
 */
public class FeatherConfig {

    // ---------------------------------------------------------------
    // GUI & Theme
    // ---------------------------------------------------------------
    @SerializedName("guiTheme")
    public String guiTheme = "dark";          // dark | light | custom

    @SerializedName("blurEnabled")
    public boolean blurEnabled = false;       // off by default — costs GPU fill rate

    @SerializedName("roundedCorners")
    public boolean roundedCorners = true;

    @SerializedName("guiAnimations")
    public boolean guiAnimations = true;

    @SerializedName("guiScale")
    public float guiScale = 1.0f;            // 0.5 – 2.0, for mobile/HiDPI scaling

    // ---------------------------------------------------------------
    // Performance
    // ---------------------------------------------------------------
    @SerializedName("fpsBoosted")
    public boolean fpsBoosted = false;        // FPS Booster Mode toggle

    @SerializedName("lowEndMode")
    public boolean lowEndMode = false;        // detected & auto-enabled on ≤4 GB RAM

    @SerializedName("minimalAnimations")
    public boolean minimalAnimations = false; // disables non-essential animations

    @SerializedName("pojavMode")
    public boolean pojavMode = false;         // special Android/PojavLauncher optimizations

    @SerializedName("particleLevel")
    public int particleLevel = 2;            // 0=off, 1=minimal, 2=decreased, 3=all

    @SerializedName("entityTickRate")
    public int entityTickRate = 20;          // ticks per second for distant entity updates

    @SerializedName("textureMipmap")
    public int textureMipmap = 4;            // mipmap levels (0-4)

    @SerializedName("reducedGc")
    public boolean reducedGc = true;         // GC-spike mitigation via object pooling

    // ---------------------------------------------------------------
    // HUD Modules (enabled state stored per-module in ModuleManager)
    // ---------------------------------------------------------------
    @SerializedName("showFpsCounter")
    public boolean showFpsCounter = true;

    @SerializedName("showCps")
    public boolean showCps = true;

    @SerializedName("showPing")
    public boolean showPing = true;

    @SerializedName("showKeystrokes")
    public boolean showKeystrokes = true;

    @SerializedName("showArmorHud")
    public boolean showArmorHud = true;

    @SerializedName("showCoordinates")
    public boolean showCoordinates = false;

    // ---------------------------------------------------------------
    // Feature Modules
    // ---------------------------------------------------------------
    @SerializedName("toggleSprint")
    public boolean toggleSprint = true;

    @SerializedName("toggleSneak")
    public boolean toggleSneak = false;

    @SerializedName("zoomEnabled")
    public boolean zoomEnabled = true;

    @SerializedName("zoomFov")
    public float zoomFov = 15.0f;           // FOV when zoomed in

    @SerializedName("zoomSmoothness")
    public float zoomSmoothness = 0.12f;    // interpolation factor

    @SerializedName("freelookEnabled")
    public boolean freelookEnabled = true;

    // ---------------------------------------------------------------
    // Crosshair
    // ---------------------------------------------------------------
    @SerializedName("customCrosshair")
    public boolean customCrosshair = false;

    @SerializedName("crosshairStyle")
    public String crosshairStyle = "default"; // default | dot | cross | circle

    @SerializedName("crosshairColor")
    public int crosshairColor = 0xFFFFFFFF;  // ARGB

    @SerializedName("crosshairSize")
    public int crosshairSize = 5;

    // ---------------------------------------------------------------
    // Cosmetics
    // ---------------------------------------------------------------
    @SerializedName("cosmeticsEnabled")
    public boolean cosmeticsEnabled = true;

    @SerializedName("capeEnabled")
    public boolean capeEnabled = true;

    @SerializedName("capePhysics")
    public boolean capePhysics = false;     // off by default — saves CPU

    @SerializedName("emotesEnabled")
    public boolean emotesEnabled = true;

    // ---------------------------------------------------------------
    // Waypoints
    // ---------------------------------------------------------------
    @SerializedName("waypointsEnabled")
    public boolean waypointsEnabled = true;

    @SerializedName("waypointBeam")
    public boolean waypointBeam = false;    // beam rendering is expensive

    // ---------------------------------------------------------------
    // Screenshot Manager
    // ---------------------------------------------------------------
    @SerializedName("screenshotNotification")
    public boolean screenshotNotification = true;

    @SerializedName("screenshotOpenFolder")
    public boolean screenshotOpenFolder = false;

    // ---------------------------------------------------------------
    // Motion Blur
    // ---------------------------------------------------------------
    @SerializedName("motionBlur")
    public boolean motionBlur = false;      // always off by default

    @SerializedName("motionBlurStrength")
    public float motionBlurStrength = 0.5f;
}
