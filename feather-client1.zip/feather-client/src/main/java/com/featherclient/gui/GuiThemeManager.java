package com.featherclient.gui;

/**
 * Manages the active GUI colour theme for all FeatherClient screens.
 *
 * All colours are cached as plain int fields — no object allocation
 * happens during rendering. Themes are defined at init time; switching
 * a theme writes new values and invalidates nothing else.
 *
 * Available themes: dark (default), light, custom
 */
public class GuiThemeManager {

    // ── Colour slots used by every FeatherClient screen ───────────────
    public int bgColor;          // window / panel background
    public int bgColorAlt;       // alternate row / secondary panel
    public int accentColor;      // primary accent (buttons, selection)
    public int accentHover;      // accent on mouse-over
    public int textColor;        // primary text
    public int textSecondary;    // dimmed / secondary text
    public int borderColor;      // border / separator
    public int scrollbarColor;   // scrollbar thumb
    public int buttonBg;         // normal button background
    public int buttonHover;      // button on hover
    public int buttonActive;     // button while pressed
    public int toggleOn;         // toggle knob — ON state
    public int toggleOff;        // toggle knob — OFF state
    public int sliderTrack;      // slider track fill
    public int sliderThumb;      // slider thumb

    private String currentTheme;

    public GuiThemeManager(String theme) {
        apply(theme);
    }

    /** Apply a named theme preset. Unknown names fall back to dark. */
    public void apply(String theme) {
        currentTheme = theme;
        switch (theme.toLowerCase()) {
            case "light"  -> applyLight();
            case "custom" -> applyDark(); // placeholder — user fills via CustomThemeScreen
            default       -> applyDark();
        }
    }

    private void applyDark() {
        bgColor        = 0xE5101010;
        bgColorAlt     = 0xE51A1A1A;
        accentColor    = 0xFF4A90E2;   // Feather blue
        accentHover    = 0xFF6AAEF8;
        textColor      = 0xFFEEEEEE;
        textSecondary  = 0xFF888888;
        borderColor    = 0xFF2A2A2A;
        scrollbarColor = 0xFF333333;
        buttonBg       = 0xFF1E1E1E;
        buttonHover    = 0xFF2A2A2A;
        buttonActive   = 0xFF383838;
        toggleOn       = 0xFF4A90E2;
        toggleOff      = 0xFF555555;
        sliderTrack    = 0xFF4A90E2;
        sliderThumb    = 0xFFDDDDDD;
    }

    private void applyLight() {
        bgColor        = 0xF0F0F0F0;
        bgColorAlt     = 0xF0E8E8E8;
        accentColor    = 0xFF2A6CBF;
        accentHover    = 0xFF3A80D8;
        textColor      = 0xFF111111;
        textSecondary  = 0xFF555555;
        borderColor    = 0xFFCCCCCC;
        scrollbarColor = 0xFF999999;
        buttonBg       = 0xFFD8D8D8;
        buttonHover    = 0xFFC8C8C8;
        buttonActive   = 0xFFB8B8B8;
        toggleOn       = 0xFF2A6CBF;
        toggleOff      = 0xFFAAAAAA;
        sliderTrack    = 0xFF2A6CBF;
        sliderThumb    = 0xFF333333;
    }

    public String getCurrentTheme() { return currentTheme; }
}
