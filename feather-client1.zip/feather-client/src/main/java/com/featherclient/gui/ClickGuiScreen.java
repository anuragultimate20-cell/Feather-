package com.featherclient.gui;

import com.featherclient.FeatherClientMod;
import com.featherclient.modules.Module;
import com.featherclient.render.HudRenderer;
import com.featherclient.render.RenderUtils;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * FeatherClient ClickGUI — a lightweight module browser / toggle screen.
 *
 * Layout:
 *   Left panel  — category tabs
 *   Right panel — module list for selected category (scrollable)
 *
 * Rendering:
 *   - Uses DrawContext batched calls only — no direct GL.
 *   - Blur panel is optional (controlled by config) to save fill rate.
 *   - All geometry is cached per-frame; no allocation in hot paths.
 *
 * Open with: Right-Click on Mod Menu FeatherClient entry,
 *            or via the configured keybind (default: R-Shift).
 */
public class ClickGuiScreen extends Screen {

    // ── Layout constants ─────────────────────────────────────────────
    private static final int CAT_PANEL_W  = 80;
    private static final int MOD_PANEL_W  = 180;
    private static final int PANEL_H      = 220;
    private static final int HEADER_H     = 20;
    private static final int ROW_H        = 18;
    private static final int PADDING      = 6;
    private static final int CORNER_R     = 6;

    // ── State ────────────────────────────────────────────────────────
    private Module.Category selectedCategory = Module.Category.HUD;
    private int scrollOffset  = 0;
    private int hoveredRow    = -1;

    // Category tabs ordered for display
    private static final Module.Category[] CATEGORIES = Module.Category.values();

    // Drag support for the whole window
    private int winX, winY;
    private boolean dragging   = false;
    private int     dragStartX, dragStartY;

    public ClickGuiScreen() {
        super(Text.literal("FeatherClient"));
    }

    @Override
    protected void init() {
        winX = (width  - CAT_PANEL_W - MOD_PANEL_W) / 2;
        winY = (height - PANEL_H)                   / 2;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        var theme  = FeatherClientMod.getGuiThemeManager();
        var hr     = new HudRenderer(ctx, delta);

        // Optional background darken (no full-screen blur by default)
        ctx.fill(0, 0, width, height, 0x66000000);

        // ── Category panel ───────────────────────────────────────────
        int cx = winX, cy = winY;
        hr.drawRoundedRect(cx, cy, cx + CAT_PANEL_W, cy + PANEL_H, theme.bgColor, CORNER_R);

        // Logo / title
        hr.drawText("✦ FC", cx + PADDING, cy + PADDING, theme.accentColor, false);

        for (int i = 0; i < CATEGORIES.length; i++) {
            Module.Category cat = CATEGORIES[i];
            int ty = cy + HEADER_H + i * ROW_H;
            boolean selected = cat == selectedCategory;
            boolean hovered  = mouseX >= cx && mouseX <= cx + CAT_PANEL_W
                            && mouseY >= ty && mouseY <= ty + ROW_H;

            int bg = selected ? theme.accentColor : hovered ? theme.buttonHover : 0;
            if (bg != 0) hr.drawRect(cx + 2, ty, cx + CAT_PANEL_W - 2, ty + ROW_H, bg);

            hr.drawText(cat.name(), cx + PADDING, ty + (ROW_H - 8) / 2,
                        selected ? 0xFFFFFFFF : theme.textColor, false);
        }

        // ── Module panel ─────────────────────────────────────────────
        int mx = winX + CAT_PANEL_W + 2, my = winY;
        hr.drawRoundedRect(mx, my, mx + MOD_PANEL_W, my + PANEL_H, theme.bgColorAlt, CORNER_R);

        hr.drawText(selectedCategory.name(), mx + PADDING, my + PADDING, theme.textColor, false);

        List<Module> modules = getModulesForCategory(selectedCategory);
        int visibleRows = (PANEL_H - HEADER_H) / ROW_H;
        scrollOffset = RenderUtils.clamp(scrollOffset, 0,
                Math.max(0, modules.size() - visibleRows));

        hoveredRow = -1;
        for (int i = scrollOffset; i < Math.min(modules.size(), scrollOffset + visibleRows); i++) {
            Module mod = modules.get(i);
            int row = i - scrollOffset;
            int ry  = my + HEADER_H + row * ROW_H;
            boolean rowHover = mouseX >= mx && mouseX <= mx + MOD_PANEL_W
                            && mouseY >= ry && mouseY <= ry + ROW_H;
            if (rowHover) hoveredRow = i;

            if (rowHover) hr.drawRect(mx + 2, ry, mx + MOD_PANEL_W - 2, ry + ROW_H, theme.buttonHover);

            // Module name
            hr.drawText(mod.getName(), mx + PADDING, ry + (ROW_H - 8) / 2,
                        mod.isEnabled() ? theme.textColor : theme.textSecondary, false);

            // Toggle indicator (right-aligned dot)
            int dotColor = mod.isEnabled() ? theme.toggleOn : theme.toggleOff;
            int dotX = mx + MOD_PANEL_W - 12;
            int dotY = ry + (ROW_H - 6) / 2;
            hr.drawRect(dotX, dotY, dotX + 6, dotY + 6, dotColor);
        }

        // Scrollbar
        if (modules.size() > visibleRows) {
            float thumbRatio  = (float) visibleRows / modules.size();
            float thumbOffset = (float) scrollOffset / modules.size();
            int trackH = PANEL_H - HEADER_H;
            int thumbH = Math.max(12, (int)(trackH * thumbRatio));
            int thumbY = my + HEADER_H + (int)(trackH * thumbOffset);
            hr.drawRect(mx + MOD_PANEL_W - 4, my + HEADER_H,
                        mx + MOD_PANEL_W - 2, my + PANEL_H, theme.borderColor);
            hr.drawRect(mx + MOD_PANEL_W - 4, thumbY,
                        mx + MOD_PANEL_W - 2, thumbY + thumbH, theme.scrollbarColor);
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int x = (int) mx, y = (int) my;

        // Category tab click
        for (int i = 0; i < CATEGORIES.length; i++) {
            int ty = winY + HEADER_H + i * ROW_H;
            if (x >= winX && x <= winX + CAT_PANEL_W && y >= ty && y <= ty + ROW_H) {
                selectedCategory = CATEGORIES[i];
                scrollOffset = 0;
                return true;
            }
        }

        // Module row click — toggle module
        int mx2 = winX + CAT_PANEL_W + 2;
        List<Module> modules = getModulesForCategory(selectedCategory);
        int visibleRows = (PANEL_H - HEADER_H) / ROW_H;
        for (int i = scrollOffset; i < Math.min(modules.size(), scrollOffset + visibleRows); i++) {
            int row = i - scrollOffset;
            int ry  = winY + HEADER_H + row * ROW_H;
            if (x >= mx2 && x <= mx2 + MOD_PANEL_W && y >= ry && y <= ry + ROW_H) {
                modules.get(i).toggle();
                // Persist state immediately
                FeatherClientMod.getModuleManager().saveState();
                return true;
            }
        }

        // Start window drag
        if (x >= winX && x <= winX + CAT_PANEL_W + MOD_PANEL_W + 2
         && y >= winY && y <= winY + HEADER_H) {
            dragging   = true;
            dragStartX = x - winX;
            dragStartY = y - winY;
            return true;
        }

        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging) {
            winX = (int) mx - dragStartX;
            winY = (int) my - dragStartY;
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        dragging = false;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hScroll, double vScroll) {
        scrollOffset -= (int) vScroll;
        return true;
    }

    @Override
    public boolean shouldPause() { return false; } // Game keeps running behind GUI

    private List<Module> getModulesForCategory(Module.Category category) {
        List<Module> result = new ArrayList<>();
        for (Module m : FeatherClientMod.getModuleManager().getModules()) {
            if (m.getCategory() == category) result.add(m);
        }
        return result;
    }
}
