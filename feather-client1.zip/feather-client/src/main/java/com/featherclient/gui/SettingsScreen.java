package com.featherclient.gui;

import com.featherclient.FeatherClientMod;
import com.featherclient.config.FeatherConfig;
import com.featherclient.render.HudRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

/**
 * Settings screen — exposes the most-used FeatherConfig options as
 * interactive widgets (sliders, toggles, theme picker).
 *
 * All widgets write directly to the in-memory FeatherConfig. The
 * config is saved to disk when the screen closes.
 */
public class SettingsScreen extends Screen {

    private static final int PANEL_W = 260;
    private static final int PANEL_H = 220;
    private static final int ROW_H   = 22;
    private static final int PAD     = 10;

    private final Screen parent;
    private final FeatherConfig cfg;

    public SettingsScreen(Screen parent) {
        super(Text.literal("FeatherClient Settings"));
        this.parent = parent;
        this.cfg    = FeatherClientMod.getConfigManager().getConfig();
    }

    @Override
    protected void init() {
        int px = (width  - PANEL_W) / 2;
        int py = (height - PANEL_H) / 2 + 20;

        // GUI Scale slider
        addDrawableChild(new SliderWidget(px + PAD, py, PANEL_W - PAD * 2, 18,
                Text.literal("GUI Scale: " + cfg.guiScale), (cfg.guiScale - 0.5f) / 1.5f) {
            @Override protected void updateMessage() {
                setMessage(Text.literal("GUI Scale: " + String.format("%.1f", value * 1.5f + 0.5f)));
            }
            @Override protected void applyValue() {
                cfg.guiScale = (float)(value * 1.5f + 0.5f);
            }
        });
        py += ROW_H + 4;

        // Zoom FOV slider
        addDrawableChild(new SliderWidget(px + PAD, py, PANEL_W - PAD * 2, 18,
                Text.literal("Zoom FOV: " + (int)cfg.zoomFov), (cfg.zoomFov - 5) / 40.0) {
            @Override protected void updateMessage() {
                setMessage(Text.literal("Zoom FOV: " + (int)(value * 40 + 5)));
            }
            @Override protected void applyValue() {
                cfg.zoomFov = (float)(value * 40 + 5);
            }
        });
        py += ROW_H + 4;

        // Theme toggle: dark / light
        addDrawableChild(ButtonWidget.builder(
                Text.literal("Theme: " + cfg.guiTheme), btn -> {
                    cfg.guiTheme = cfg.guiTheme.equals("dark") ? "light" : "dark";
                    FeatherClientMod.getGuiThemeManager().apply(cfg.guiTheme);
                    btn.setMessage(Text.literal("Theme: " + cfg.guiTheme));
                })
                .dimensions(px + PAD, py, PANEL_W - PAD * 2, 18)
                .build());
        py += ROW_H + 4;

        // Blur toggle
        addDrawableChild(ButtonWidget.builder(
                Text.literal("Blur: " + (cfg.blurEnabled ? "On" : "Off")), btn -> {
                    cfg.blurEnabled = !cfg.blurEnabled;
                    btn.setMessage(Text.literal("Blur: " + (cfg.blurEnabled ? "On" : "Off")));
                })
                .dimensions(px + PAD, py, PANEL_W - PAD * 2, 18)
                .build());
        py += ROW_H + 4;

        // Cape physics toggle
        addDrawableChild(ButtonWidget.builder(
                Text.literal("Cape Physics: " + (cfg.capePhysics ? "On" : "Off")), btn -> {
                    cfg.capePhysics = !cfg.capePhysics;
                    btn.setMessage(Text.literal("Cape Physics: " + (cfg.capePhysics ? "On" : "Off")));
                })
                .dimensions(px + PAD, py, PANEL_W - PAD * 2, 18)
                .build());
        py += ROW_H + 4;

        // Reset to defaults
        addDrawableChild(ButtonWidget.builder(
                Text.literal("Reset Defaults"), btn -> {
                    FeatherClientMod.getConfigManager().resetToDefaults();
                    client.setScreen(new SettingsScreen(parent));
                })
                .dimensions(px + PAD, py, (PANEL_W - PAD * 3) / 2, 18)
                .build());

        // Back
        addDrawableChild(ButtonWidget.builder(
                Text.literal("← Back"), btn -> close())
                .dimensions(px + PAD + (PANEL_W - PAD * 3) / 2 + PAD, py,
                            (PANEL_W - PAD * 3) / 2, 18)
                .build());
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        var theme = FeatherClientMod.getGuiThemeManager();
        var hr    = new HudRenderer(ctx, delta);

        int px = (width  - PANEL_W) / 2;
        int py = (height - PANEL_H) / 2;

        ctx.fill(0, 0, width, height, 0x88000000);
        hr.drawRoundedRect(px, py, px + PANEL_W, py + PANEL_H + 30, theme.bgColor, 6);
        hr.drawText("Settings", px + PAD, py + PAD, theme.textColor, false);

        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public void close() {
        FeatherClientMod.getConfigManager().save();
        client.setScreen(parent);
    }
}
