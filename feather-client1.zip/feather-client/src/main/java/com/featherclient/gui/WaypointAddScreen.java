package com.featherclient.gui;

import com.featherclient.FeatherClientMod;
import com.featherclient.modules.render.WaypointsModule;
import com.featherclient.render.HudRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

/**
 * Simple dialog screen for adding a new waypoint at the player's
 * current position.  Opened from the ClickGUI waypoints section.
 *
 * Layout:
 *   - Name text field
 *   - Color picker row (preset ARGB swatches)
 *   - Add / Cancel buttons
 */
public class WaypointAddScreen extends Screen {

    private static final int PANEL_W = 200;
    private static final int PANEL_H = 120;
    private static final int CORNER  = 6;

    private static final int[] PRESET_COLORS = {
        0xFFFF5555, 0xFFFFAA00, 0xFFFFFF55,
        0xFF55FF55, 0xFF55FFFF, 0xFF5555FF,
        0xFFFF55FF, 0xFFFFFFFF
    };

    private TextFieldWidget nameField;
    private int selectedColor = PRESET_COLORS[0];
    private final Screen parent;

    public WaypointAddScreen(Screen parent) {
        super(Text.literal("Add Waypoint"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int px = (width  - PANEL_W) / 2;
        int py = (height - PANEL_H) / 2;

        // Name field
        nameField = new TextFieldWidget(textRenderer, px + 10, py + 30, PANEL_W - 20, 18,
                Text.literal("Waypoint Name"));
        nameField.setMaxLength(24);
        nameField.setFocused(true);
        addSelectableChild(nameField);

        // Add button
        addDrawableChild(ButtonWidget.builder(Text.literal("Add"), btn -> addWaypoint())
                .dimensions(px + 10, py + PANEL_H - 28, 85, 18)
                .build());

        // Cancel button
        addDrawableChild(ButtonWidget.builder(Text.literal("Cancel"), btn -> close())
                .dimensions(px + PANEL_W - 95, py + PANEL_H - 28, 85, 18)
                .build());
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        var theme = FeatherClientMod.getGuiThemeManager();
        var hr    = new HudRenderer(ctx, delta);

        int px = (width  - PANEL_W) / 2;
        int py = (height - PANEL_H) / 2;

        // Panel background
        hr.drawRoundedRect(px, py, px + PANEL_W, py + PANEL_H, theme.bgColor, CORNER);
        hr.drawText("Add Waypoint", px + 10, py + 10, theme.textColor, false);

        // Color swatches
        int swatchX = px + 10;
        int swatchY = py + 58;
        for (int i = 0; i < PRESET_COLORS.length; i++) {
            int cx = swatchX + i * 22;
            hr.drawRect(cx, swatchY, cx + 16, swatchY + 16, PRESET_COLORS[i]);
            if (PRESET_COLORS[i] == selectedColor) {
                // Selection border
                ctx.drawBorder(cx - 1, swatchY - 1, 18, 18, 0xFFFFFFFF);
            }
        }
        hr.drawText("Color:", px + 10, swatchY - 11, theme.textSecondary, false);

        nameField.render(ctx, mouseX, mouseY, delta);
        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        // Color swatch selection
        int px = (width  - PANEL_W) / 2;
        int py = (height - PANEL_H) / 2;
        int swatchX = px + 10;
        int swatchY = py + 58;
        for (int i = 0; i < PRESET_COLORS.length; i++) {
            int cx = swatchX + i * 22;
            if (mx >= cx && mx <= cx + 16 && my >= swatchY && my <= swatchY + 16) {
                selectedColor = PRESET_COLORS[i];
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    private void addWaypoint() {
        String name = nameField.getText().trim();
        if (name.isEmpty()) name = "Waypoint";

        var mc = net.minecraft.client.MinecraftClient.getInstance();
        if (mc.player == null) { close(); return; }

        var wp = new WaypointsModule.Waypoint(
                name,
                mc.player.getX(),
                mc.player.getY(),
                mc.player.getZ(),
                selectedColor
        );

        FeatherClientMod.getModuleManager()
                .getByType(WaypointsModule.class)
                .ifPresent(wm -> wm.addWaypoint(wp));

        close();
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }
}
