package com.featherclient.modules.hud;

import com.featherclient.render.HudRenderer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.ItemStack;

/**
 * Armor HUD — shows current durability of each armor piece.
 *
 * Slots (index 3..0 = helmet..boots) are rendered as small durability
 * bars with the item icon cached by Minecraft's item renderer.
 *
 * No allocation during rendering — uses stack-local primitives only.
 */
public class ArmorHudModule extends HudModule {

    private static final int ICON_SIZE  = 16;
    private static final int BAR_HEIGHT = 2;
    private static final int ROW_HEIGHT = ICON_SIZE + BAR_HEIGHT + 2;

    public ArmorHudModule() {
        super("Armor HUD", "Displays armor durability.", 4, 160);
        setWidth(ICON_SIZE + 30);
        setHeight(ROW_HEIGHT * 4);
    }

    @Override
    public void onTick() {
        // No per-tick work — reads item stacks in render() at frame rate
    }

    @Override
    public void render(HudRenderer renderer, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        // Armor slots 3 (helmet) → 0 (boots)
        for (int slotIdx = 3; slotIdx >= 0; slotIdx--) {
            ItemStack stack = mc.player.getInventory().getArmorStack(slotIdx);
            if (stack.isEmpty()) continue;

            int row = 3 - slotIdx;
            int y   = getY() + row * ROW_HEIGHT;

            // Draw item icon (Minecraft's item renderer handles caching)
            renderer.drawItem(stack, getX(), y);

            // Draw durability bar underneath the icon
            if (stack.isDamageable()) {
                float durability = 1.0f - (float) stack.getDamage() / stack.getMaxDamage();
                int   barWidth   = (int) (durability * ICON_SIZE);
                int   barColor   = durabilityColor(durability);
                renderer.drawRect(getX(), y + ICON_SIZE + 1, getX() + ICON_SIZE, y + ICON_SIZE + 1 + BAR_HEIGHT, 0x88000000);
                renderer.drawRect(getX(), y + ICON_SIZE + 1, getX() + barWidth,  y + ICON_SIZE + 1 + BAR_HEIGHT, barColor);
            }
        }
    }

    /** Gradient from red (0%) through yellow (50%) to green (100%). */
    private int durabilityColor(float t) {
        int r = (int) (255 * (1.0f - t));
        int g = (int) (255 * t);
        return 0xFF000000 | (r << 16) | (g << 8);
    }
}
