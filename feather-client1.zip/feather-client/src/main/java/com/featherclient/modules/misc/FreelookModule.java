package com.featherclient.modules.misc;

import com.featherclient.modules.Module;
import net.minecraft.client.MinecraftClient;

/**
 * Freelook — rotate the camera while keeping movement direction fixed.
 *
 * While the freelook key is held, we capture the mouse delta in our
 * mixin and add it to an independent pitch/yaw offset instead of the
 * player's actual rotation.  On release the camera snaps back.
 *
 * MixinGameRenderer reads getFreelookYaw() / getFreelookPitch() to
 * apply the offset to the camera matrix.
 */
public class FreelookModule extends Module {

    private boolean active     = false;
    private float   yawOffset  = 0.0f;
    private float   pitchOffset = 0.0f;

    public FreelookModule() {
        super("Freelook", Category.MOVEMENT, "Hold V to look around without turning.");
    }

    /** Called by MixinMouseHandler when the freelook key changes state. */
    public void setActive(boolean active) {
        if (!active) {
            yawOffset   = 0.0f;
            pitchOffset = 0.0f;
        }
        this.active = active;
    }

    public boolean isActive() { return active; }

    /**
     * Accumulate mouse deltas while freelook is active.
     * Called from mixin BEFORE the normal mouse-look handler so we can
     * consume the delta without rotating the player.
     *
     * @return true if the delta was consumed (mixin should skip normal look)
     */
    public boolean handleMouseDelta(double dx, double dy) {
        if (!active || !isEnabled()) return false;
        float sensitivity = MinecraftClient.getInstance().options.getMouseSensitivity().getValue().floatValue();
        yawOffset   += (float) dx * sensitivity * 0.15f;
        pitchOffset += (float) dy * sensitivity * 0.15f;
        pitchOffset = Math.max(-90.0f, Math.min(90.0f, pitchOffset));
        return true;
    }

    public float getFreelookYaw()   { return yawOffset;   }
    public float getFreelookPitch() { return pitchOffset; }

    @Override
    public void onDisable() {
        active      = false;
        yawOffset   = 0.0f;
        pitchOffset = 0.0f;
    }
}
