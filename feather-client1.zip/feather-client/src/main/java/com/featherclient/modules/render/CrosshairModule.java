package com.featherclient.modules.render;

import com.featherclient.FeatherClientMod;
import com.featherclient.modules.Module;
import com.featherclient.render.HudRenderer;

/**
 * Custom Crosshair renderer.
 *
 * Styles: default (vanilla), dot, cross, circle
 * The mixin MixinInGameHud suppresses the vanilla crosshair when this
 * module is enabled, then calls renderCustomCrosshair() in its place.
 *
 * All drawing uses HudRenderer's batched line/rect primitives —
 * no extra GL state changes, no shader switches.
 */
public class CrosshairModule extends Module {

    public enum Style { DEFAULT, DOT, CROSS, CIRCLE }

    private Style style       = Style.CROSS;
    private int   color       = 0xFFFFFFFF;
    private int   size        = 5;
    private float lineWidth   = 1.0f;

    public CrosshairModule() {
        super("Crosshair", Category.RENDER, "Custom crosshair with multiple styles.");
    }

    @Override
    public void onEnable() {
        var cfg = FeatherClientMod.getConfigManager().getConfig();
        style = Style.valueOf(cfg.crosshairStyle.toUpperCase());
        color = cfg.crosshairColor;
        size  = cfg.crosshairSize;
    }

    /**
     * Render the crosshair at the centre of the screen.
     * Called from MixinInGameHud instead of vanilla crosshair.
     */
    public void renderCustomCrosshair(HudRenderer renderer, int screenW, int screenH) {
        int cx = screenW / 2;
        int cy = screenH / 2;

        switch (style) {
            case DOT    -> renderer.drawRect(cx - 1, cy - 1, cx + 1, cy + 1, color);
            case CROSS  -> renderCross(renderer, cx, cy);
            case CIRCLE -> renderCircle(renderer, cx, cy);
            default     -> { /* let vanilla draw */ }
        }
    }

    private void renderCross(HudRenderer r, int cx, int cy) {
        // Horizontal bar
        r.drawRect(cx - size, cy - 1, cx + size + 1, cy + 1, color);
        // Vertical bar
        r.drawRect(cx - 1, cy - size, cx + 1, cy + size + 1, color);
    }

    private void renderCircle(HudRenderer r, int cx, int cy) {
        // Approximate circle with 16 rects (cheap, no trig at runtime)
        double step = Math.PI * 2 / 16;
        for (int i = 0; i < 16; i++) {
            double angle = i * step;
            int px = cx + (int) (Math.cos(angle) * size);
            int py = cy + (int) (Math.sin(angle) * size);
            r.drawRect(px - 1, py - 1, px + 1, py + 1, color);
        }
    }

    public void setStyle(Style s) { style = s; }
    public void setColor(int c)   { color = c; }
    public void setSize(int s)    { size  = s; }
}
