package com.featherclient.modules.misc;

import com.featherclient.modules.Module;
import net.minecraft.client.MinecraftClient;

/**
 * Toggle Sprint — keeps the player sprinting without holding the key.
 *
 * Activates sprinting every tick while enabled, forward is held, and
 * the player is able to sprint (has food, not sneaking, etc.).
 * Zero overhead when the player is not moving forward.
 */
public class ToggleSprintModule extends Module {

    public ToggleSprintModule() {
        super("Toggle Sprint", Category.MOVEMENT, "Automatically keeps you sprinting.");
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;

        // Only sprint when moving forward and sprint is not already locked
        if (mc.options.forwardKey.isPressed()
                && !mc.player.isSneaking()
                && mc.player.getHungerManager().getFoodLevel() > 6
                && !mc.player.isSprinting()) {
            mc.player.setSprinting(true);
        }
    }

    @Override
    public void onDisable() {
        // Stop sprinting immediately when module is disabled
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) mc.player.setSprinting(false);
    }
}
