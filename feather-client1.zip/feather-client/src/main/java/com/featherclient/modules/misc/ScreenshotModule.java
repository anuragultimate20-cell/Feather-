package com.featherclient.modules.misc;

import com.featherclient.modules.Module;
import com.featherclient.utils.Logger;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.minecraft.util.Util;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Screenshot Manager — enhances Minecraft's built-in screenshot with:
 *  - Toast notification on capture
 *  - Organised subfolder by date (screenshots/YYYY-MM-DD/)
 *  - Optional auto-open folder after capture
 *
 * The actual image capture still uses Minecraft's native utility
 * (zero GPU overhead change); we only intercept the post-capture hook.
 */
public class ScreenshotModule extends Module {

    private static final DateTimeFormatter DATE_FMT =
            DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private boolean openFolderOnCapture = false;

    public ScreenshotModule() {
        super("Screenshot Manager", Category.MISC,
              "Organises screenshots into dated folders.");
    }

    /** Called from MixinMinecraftClient after a screenshot is taken. */
    public void onScreenshotTaken(Path screenshotFile) {
        if (!isEnabled()) return;

        // Move into dated subfolder asynchronously — never blocks render thread
        Thread.ofVirtual().name("feather-screenshot-organiser").start(() -> {
            try {
                organise(screenshotFile);
            } catch (IOException e) {
                Logger.warn("Failed to organise screenshot: " + e.getMessage());
            }
        });
    }

    private void organise(Path file) throws IOException {
        if (!Files.exists(file)) return;

        Path dateDir = file.getParent()
                .resolve(LocalDateTime.now().format(DATE_FMT));
        Files.createDirectories(dateDir);
        Path dest = dateDir.resolve(file.getFileName());
        Files.move(file, dest);

        if (openFolderOnCapture) {
            Util.getOperatingSystem().open(dateDir.toFile());
        }
    }

    public void setOpenFolderOnCapture(boolean v) { openFolderOnCapture = v; }
}
