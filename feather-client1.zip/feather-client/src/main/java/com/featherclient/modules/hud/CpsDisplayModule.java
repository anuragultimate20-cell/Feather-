package com.featherclient.modules.hud;

import com.featherclient.render.HudRenderer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * CPS (Clicks Per Second) display.
 *
 * Tracks left and right mouse button clicks in a 1-second sliding
 * window using a timestamp deque — O(1) per click, O(k) cleanup
 * where k = clicks in the last second (typically very small).
 */
public class CpsDisplayModule extends HudModule {

    /** Timestamps (ms) of left-button clicks within the last second. */
    private final Deque<Long> leftClicks  = new ArrayDeque<>();
    /** Timestamps (ms) of right-button clicks within the last second. */
    private final Deque<Long> rightClicks = new ArrayDeque<>();

    private String cachedLabel = "CPS: 0 | 0";

    public CpsDisplayModule() {
        super("CPS Display", "Shows clicks per second (left | right).", 4, 16);
    }

    @Override
    public void onEnable() {
        // No subscription needed — we poll button state each tick
    }

    /** Record a left click. Called from mixin. */
    public void recordLeft() {
        leftClicks.addLast(System.currentTimeMillis());
    }

    /** Record a right click. Called from mixin. */
    public void recordRight() {
        rightClicks.addLast(System.currentTimeMillis());
    }

    @Override
    public void onTick() {
        long now    = System.currentTimeMillis();
        long cutoff = now - 1000L;

        // Evict clicks older than 1 second from the front of each deque
        while (!leftClicks.isEmpty()  && leftClicks.peekFirst()  < cutoff) leftClicks.pollFirst();
        while (!rightClicks.isEmpty() && rightClicks.peekFirst() < cutoff) rightClicks.pollFirst();

        cachedLabel = "CPS: " + leftClicks.size() + " | " + rightClicks.size();
    }

    @Override
    public void render(HudRenderer renderer, float tickDelta) {
        renderer.drawText(cachedLabel, getX(), getY(), 0xFFFFFFFF, true);
    }
}
