package com.featherclient.modules.render;

import com.featherclient.modules.Module;

/**
 * Motion Blur — lightweight accumulation-based blur.
 *
 * OFF by default (performance cost). When enabled, MixinGameRenderer
 * reads getStrength() to blend the previous frame into the current one.
 *
 * Uses no shader compilation at runtime — only a simple alpha-blended
 * blit, which is compatible with ImmediatelyFast and Sodium.
 */
public class MotionBlurModule extends Module {

    private float strength = 0.5f; // 0.0 = no blur, 1.0 = full persistence

    public MotionBlurModule() {
        super("Motion Blur", Category.RENDER,
              "Blends previous frame for a motion-blur effect. Off by default.");
    }

    public float getStrength()       { return strength;        }
    public void  setStrength(float s){ strength = clamp(s, 0, 0.95f); }

    private static float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }
}
