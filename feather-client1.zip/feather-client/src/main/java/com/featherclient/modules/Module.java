package com.featherclient.modules;

/**
 * Base class for every FeatherClient feature module.
 *
 * Each module has:
 *  - A unique name and display category
 *  - An enabled/disabled toggle
 *  - An optional keybind (key code, -1 = none)
 *  - Lifecycle hooks: onEnable, onDisable, onTick
 *
 * Modules must be lightweight. The onTick() method runs every
 * game tick (20/s), so avoid any allocation or I/O there.
 */
public abstract class Module {

    public enum Category {
        HUD,
        MOVEMENT,
        RENDER,
        MISC,
        COSMETICS,
        PERFORMANCE
    }

    private final String   name;
    private final Category category;
    private final String   description;

    /** GLFW key code, or -1 for no binding. */
    private int     keybind = -1;
    private boolean enabled = false;

    protected Module(String name, Category category, String description) {
        this.name        = name;
        this.category    = category;
        this.description = description;
    }

    // ---------------------------------------------------------------
    // Lifecycle — override as needed
    // ---------------------------------------------------------------

    /** Called once when the module is toggled ON. */
    public void onEnable() {}

    /** Called once when the module is toggled OFF. */
    public void onDisable() {}

    /**
     * Called every game tick while the module is enabled.
     * Keep this O(1) and allocation-free.
     */
    public void onTick() {}

    // ---------------------------------------------------------------
    // Toggle
    // ---------------------------------------------------------------

    public void toggle() {
        setEnabled(!enabled);
    }

    public void setEnabled(boolean enabled) {
        if (this.enabled == enabled) return;
        this.enabled = enabled;
        if (enabled) onEnable();
        else         onDisable();
    }

    // ---------------------------------------------------------------
    // Accessors
    // ---------------------------------------------------------------

    public String   getName()        { return name;        }
    public Category getCategory()    { return category;    }
    public String   getDescription() { return description; }
    public boolean  isEnabled()      { return enabled;     }
    public int      getKeybind()     { return keybind;     }
    public void     setKeybind(int k){ this.keybind = k;   }

    @Override
    public String toString() {
        return name + "[" + (enabled ? "ON" : "OFF") + "]";
    }
}
