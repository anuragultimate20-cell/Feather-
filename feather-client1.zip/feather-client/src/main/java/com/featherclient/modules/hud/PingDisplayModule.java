package com.featherclient.modules.hud;

import com.featherclient.render.HudRenderer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;

/**
 * Ping / latency display.
 *
 * Reads latency from the player list — the same value Minecraft uses
 * for the tab-list ping icon. No extra network overhead.
 *
 * Update rate: once per second via tick counter to avoid redundant
 * work every frame.
 */
public class PingDisplayModule extends HudModule {

    private int    cachedPing  = 0;
    private String cachedLabel = "Ping: 0 ms";
    private int    tickCounter = 0;

    // Refresh ping reading every 20 ticks (1 second)
    private static final int REFRESH_TICKS = 20;

    public PingDisplayModule() {
        super("Ping Display", "Shows your current server latency.", 4, 28);
    }

    @Override
    public void onTick() {
        if (++tickCounter < REFRESH_TICKS) return;
        tickCounter = 0;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.getNetworkHandler() == null) {
            cachedLabel = "Ping: --";
            return;
        }

        PlayerListEntry entry = mc.getNetworkHandler()
                .getPlayerListEntry(mc.player.getUuid());
        if (entry != null) {
            int ping = entry.getLatency();
            if (ping != cachedPing) {
                cachedPing  = ping;
                cachedLabel = "Ping: " + ping + " ms";
            }
        }
    }

    @Override
    public void render(HudRenderer renderer, float tickDelta) {
        renderer.drawText(cachedLabel, getX(), getY(), getPingColor(cachedPing), true);
    }

    /** Green ≤ 80 ms, yellow ≤ 200 ms, red > 200 ms. */
    private int getPingColor(int ping) {
        if (ping <= 80)  return 0xFF55FF55;
        if (ping <= 200) return 0xFFFFFF55;
        return 0xFFFF5555;
    }
}
