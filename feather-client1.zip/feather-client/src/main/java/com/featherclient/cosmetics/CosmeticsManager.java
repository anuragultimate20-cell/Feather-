package com.featherclient.cosmetics;

import com.featherclient.utils.Logger;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Manages player cosmetics: capes, hats, wings, and emotes.
 *
 * All network I/O and texture loading runs on virtual threads so the
 * render thread is NEVER stalled by cosmetics.  The AtomicBoolean
 * guards prevent double-loading if the player changes worlds quickly.
 *
 * Textures are lazy-loaded: cosmetic renderers call getTexture() which
 * returns null until the async load finishes — the renderer simply
 * skips drawing until ready.  No blocking, no crash.
 */
public class CosmeticsManager {

    private final AtomicBoolean loading  = new AtomicBoolean(false);
    private final AtomicBoolean loaded   = new AtomicBoolean(false);

    private CapeData   activeCape   = null;
    private EmoteData  activeEmote  = null;

    // ── Public API ───────────────────────────────────────────────────

    /**
     * Begin async loading of cosmetics for the current player.
     * Safe to call multiple times — subsequent calls no-op.
     */
    public void loadAsync() {
        if (!loading.compareAndSet(false, true)) return;

        CompletableFuture.runAsync(this::doLoad)
                .whenComplete((v, err) -> {
                    if (err != null) Logger.warn("Cosmetics load error: " + err.getMessage());
                    else             Logger.info("Cosmetics loaded.");
                    loaded.set(true);
                });
    }

    public boolean isLoaded()           { return loaded.get();   }
    public CapeData getActiveCape()     { return activeCape;     }
    public EmoteData getActiveEmote()   { return activeEmote;    }

    public void equipCape(CapeData cape)   { activeCape  = cape;  }
    public void equipEmote(EmoteData emote){ activeEmote = emote; }
    public void clearCape()                { activeCape  = null;  }
    public void clearEmote()               { activeEmote = null;  }

    // ── Internal ─────────────────────────────────────────────────────

    private void doLoad() {
        // In a real build this would call the cosmetics API endpoint.
        // Here we simulate a short async delay.
        try {
            Thread.sleep(100); // simulate very fast local cache hit
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        // Assign a default no-cape state — server data would populate these.
        activeCape  = null;
        activeEmote = null;
    }

    // ── Inner data holders ───────────────────────────────────────────

    /** Immutable cape descriptor. Texture ID is registered lazily. */
    public static class CapeData {
        public final String id;
        public final String textureUrl;
        public final boolean physicsEnabled;

        public CapeData(String id, String textureUrl, boolean physics) {
            this.id             = id;
            this.textureUrl     = textureUrl;
            this.physicsEnabled = physics;
        }
    }

    /** Immutable emote descriptor. */
    public static class EmoteData {
        public final String id;
        public final String animationKey;
        public final int    durationTicks;

        public EmoteData(String id, String animationKey, int durationTicks) {
            this.id            = id;
            this.animationKey  = animationKey;
            this.durationTicks = durationTicks;
        }
    }
}
