package com.featherclient.mixin;

import com.featherclient.FeatherClientMod;
import com.featherclient.modules.misc.FreelookModule;
import com.featherclient.modules.misc.ZoomModule;
import net.minecraft.client.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Hooks into the Mouse handler to:
 *  1. Forward scroll events to ZoomModule for FOV adjustment
 *  2. Intercept mouse-look deltas for FreelookModule
 */
@Mixin(Mouse.class)
public class MixinMouseHandler {

    /** Intercept scroll to adjust zoom FOV. */
    @Inject(method = "onMouseScroll", at = @At("HEAD"), cancellable = false)
    private void feather$onScroll(long window, double horizontal, double vertical, CallbackInfo ci) {
        var mm = FeatherClientMod.getModuleManager();
        if (mm == null) return;

        mm.getByType(ZoomModule.class).ifPresent(z -> {
            if (z.isEnabled() && z.isZoomed()) {
                z.scroll(vertical);
            }
        });
    }

    /**
     * Intercept cursor movement for FreelookModule.
     * If freelook is active and consumes the delta, we cancel the
     * normal player rotation update.
     */
    @Inject(method = "updateMouse", at = @At("HEAD"), cancellable = true)
    private void feather$onMouseMove(CallbackInfo ci) {
        var mm = FeatherClientMod.getModuleManager();
        if (mm == null) return;

        mm.getByType(FreelookModule.class).ifPresent(fl -> {
            if (fl.isEnabled() && fl.isActive()) {
                // Let FreelookModule handle the delta — cancel normal look
                // The actual delta capture happens inside FreelookModule.handleMouseDelta()
                // which is called from the Fabric mouse callback hook below.
                // We only cancel here if the module truly consumed input.
                ci.cancel();
            }
        });
    }
}
