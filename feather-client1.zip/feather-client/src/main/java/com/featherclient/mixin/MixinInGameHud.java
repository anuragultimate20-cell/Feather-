package com.featherclient.mixin;

import com.featherclient.FeatherClientMod;
import com.featherclient.modules.Module;
import com.featherclient.modules.hud.HudModule;
import com.featherclient.modules.render.CrosshairModule;
import com.featherclient.render.HudRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Hooks into InGameHud to:
 *  1. Render all enabled HudModule overlays after the vanilla HUD
 *  2. Suppress the vanilla crosshair when CrosshairModule is active
 */
@Mixin(InGameHud.class)
public class MixinInGameHud {

    /** Render FeatherClient HUD elements after all vanilla HUD rendering. */
    @Inject(method = "render", at = @At("TAIL"))
    private void feather$renderHud(DrawContext ctx, float tickDelta, CallbackInfo ci) {
        var mm = FeatherClientMod.getModuleManager();
        if (mm == null) return;

        HudRenderer renderer = new HudRenderer(ctx, tickDelta);

        for (Module m : mm.getModules()) {
            if (m instanceof HudModule hm && hm.isEnabled()) {
                try {
                    hm.render(renderer, tickDelta);
                } catch (Exception e) {
                    // Never crash the game due to a HUD module
                }
            }
        }
    }

    /** Cancel vanilla crosshair draw when the custom crosshair module is active. */
    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
    private void feather$customCrosshair(DrawContext ctx, float tickDelta, CallbackInfo ci) {
        var mm = FeatherClientMod.getModuleManager();
        if (mm == null) return;

        mm.getByType(CrosshairModule.class).ifPresent(mod -> {
            if (mod.isEnabled()) {
                ci.cancel();
                var mc = net.minecraft.client.MinecraftClient.getInstance();
                HudRenderer hr = new HudRenderer(ctx, tickDelta);
                mod.renderCustomCrosshair(hr, mc.getWindow().getScaledWidth(),
                                              mc.getWindow().getScaledHeight());
            }
        });
    }
}
