package com.featherclient.render;

import net.minecraft.client.gui.DrawContext;

/**
 * Static render utilities shared across GUI and HUD code.
 *
 * All methods are pure functions or simple GL-state helpers.
 * Never allocate objects here — methods may be called every frame.
 */
public final class RenderUtils {

    private RenderUtils() {}

    // ── Color helpers ────────────────────────────────────────────────

    /** Blend two ARGB colors by factor t (0.0 = a, 1.0 = b). */
    public static int lerpColor(int a, int b, float t) {
        int ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF, aa = (a >> 24) & 0xFF;
        int br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF, ba = (b >> 24) & 0xFF;
        int r = (int)(ar + (br - ar) * t);
        int g = (int)(ag + (bg - ag) * t);
        int bl = (int)(ab + (bb - ab) * t);
        int al = (int)(aa + (ba - aa) * t);
        return (al << 24) | (r << 16) | (g << 8) | bl;
    }

    /** Multiply an ARGB color's alpha by factor (0.0–1.0). */
    public static int withAlpha(int argb, float alpha) {
        int a = (int)(((argb >> 24) & 0xFF) * alpha);
        return (argb & 0x00FFFFFF) | (a << 24);
    }

    /** Extract individual channels. */
    public static int alpha(int argb) { return (argb >> 24) & 0xFF; }
    public static int red  (int argb) { return (argb >> 16) & 0xFF; }
    public static int green(int argb) { return (argb >>  8) & 0xFF; }
    public static int blue (int argb) { return  argb        & 0xFF; }

    // ── Animation easing ─────────────────────────────────────────────

    /** Smooth-step: t → 3t²−2t³ (S-curve). Zero derivative at t=0 and t=1. */
    public static float smoothStep(float t) {
        t = Math.max(0, Math.min(1, t));
        return t * t * (3 - 2 * t);
    }

    /** Ease-out cubic: fast start, slow end. Good for opening menus. */
    public static float easeOut(float t) {
        float inv = 1 - t;
        return 1 - inv * inv * inv;
    }

    // ── Geometry ─────────────────────────────────────────────────────

    public static boolean pointInRect(int px, int py, int x, int y, int w, int h) {
        return px >= x && px <= x + w && py >= y && py <= y + h;
    }

    /** Clamp int value within [min, max]. */
    public static int clamp(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }

    public static float clampf(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }
}
