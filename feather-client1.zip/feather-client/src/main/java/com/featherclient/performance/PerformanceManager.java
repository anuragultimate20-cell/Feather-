package com.featherclient.performance;

import com.featherclient.utils.Logger;
import net.minecraft.client.MinecraftClient;

/**
 * Detects device capabilities at startup and applies appropriate
 * performance presets automatically.
 *
 * Detection strategy:
 *  1. Total JVM max heap  → rough RAM indicator
 *  2. Available CPU cores → thread budget
 *  3. System property for PojavLauncher detection
 *
 * All decisions are made once at init — no runtime polling.
 */
public class PerformanceManager {

    public enum Tier { HIGH, MEDIUM, LOW, POJAV }

    private Tier    tier        = Tier.HIGH;
    private boolean lowEnd      = false;
    private boolean isPojavMode = false;

    // Thresholds (bytes)
    private static final long RAM_LOW    = 4L  * 1024 * 1024 * 1024; // ≤ 4 GB → LOW
    private static final long RAM_MEDIUM = 8L  * 1024 * 1024 * 1024; // ≤ 8 GB → MEDIUM

    public void detectAndApply() {
        // PojavLauncher injects this system property
        isPojavMode = System.getProperty("pojav_launcher") != null
                   || System.getProperty("user.name", "").equalsIgnoreCase("pojav");

        long maxRam  = Runtime.getRuntime().maxMemory();
        int  cores   = Runtime.getRuntime().availableProcessors();

        if (isPojavMode) {
            tier   = Tier.POJAV;
            lowEnd = true;
        } else if (maxRam <= RAM_LOW || cores <= 2) {
            tier   = Tier.LOW;
            lowEnd = true;
        } else if (maxRam <= RAM_MEDIUM || cores <= 4) {
            tier   = Tier.MEDIUM;
            lowEnd = false;
        } else {
            tier   = Tier.HIGH;
            lowEnd = false;
        }

        Logger.info("PerformanceManager: tier=" + tier
                + " RAM=" + (maxRam / 1024 / 1024) + "MB"
                + " cores=" + cores
                + " pojav=" + isPojavMode);
    }

    /**
     * Apply recommended MC options for the detected tier.
     * Called after MinecraftClient finishes loading.
     */
    public void applyGameOptions(MinecraftClient mc) {
        if (mc == null || mc.options == null) return;

        switch (tier) {
            case POJAV, LOW -> {
                // Minimum quality — max performance
                mc.options.getEntityDistanceScaling().setValue(0.5);
                mc.options.getSimulationDistance().setValue(5);
                mc.options.getViewDistance().setValue(6);
                mc.options.getParticles().setValue(net.minecraft.client.option.ParticlesMode.MINIMAL);
                mc.options.getFancyGraphics().setValue(false);
                mc.options.getCloudRenderMode().setValue(net.minecraft.client.option.CloudRenderMode.OFF);
                mc.options.getMipmapLevels().setValue(1);
            }
            case MEDIUM -> {
                mc.options.getEntityDistanceScaling().setValue(0.75);
                mc.options.getSimulationDistance().setValue(8);
                mc.options.getMipmapLevels().setValue(2);
                mc.options.getParticles().setValue(net.minecraft.client.option.ParticlesMode.DECREASED);
            }
            case HIGH -> {
                // Don't override — let user/Sodium handle it
            }
        }
    }

    // ── Accessors ────────────────────────────────────────────────────

    public Tier    getTier()       { return tier;        }
    public boolean isLowEnd()     { return lowEnd;      }
    public boolean isPojavMode()  { return isPojavMode; }
}
